# CSC4740Project

The dataset can be found [here](https://www.kaggle.com/datasets/ikarus777/best-artworks-of-all-time)

Training routine is run directly with main.py, while visualization functions are exported in visualization.py. The cleaning.py file should be run once before any other processing. 